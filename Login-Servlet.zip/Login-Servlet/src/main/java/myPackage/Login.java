
package myPackage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/login")
public class Login extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.getRequestDispatcher("index.jsp").forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
        user.setUsername(request.getParameter("username"));
        user.setPassword(request.getParameter("password"));
        String check = request.getParameter("check");
        UserDao userDao = new UserDao();
        if(userDao.validateUser(user)){
            request.getSession().setAttribute("username",user);
            if("wel".equals(check)){
                Cookie cookie =new Cookie("meme",user.getUsername());
                cookie.setMaxAge(30 * 24 * 60 * 60);
                response.addCookie(cookie);
            }else{
                Cookie cookie = new Cookie("meme",null);
                cookie.setMaxAge(0);
                response.addCookie(cookie);
            }


            response.sendRedirect("Welcome.jsp");




        } else{

            request.getSession().setAttribute("errorMessage", "Invalid login and password, try again!");

            response.sendRedirect("index.jsp");

        }


    }
}


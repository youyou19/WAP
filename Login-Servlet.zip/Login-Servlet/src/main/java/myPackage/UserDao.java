package myPackage;


import java.util.ArrayList;
import java.util.List;

public class UserDao {
    // User es=new User();
    private  List<User> uses=new ArrayList<>();

    public UserDao(){
        User user = new User("jules", "pass");
        User user1 = new User("jeo", "pass1");
        uses.add(user);
        uses.add(user1);
        uses.add(new User("test", "test"));

    }


    public boolean validateUser(User user){
        for(User use: uses){
            if(use.getUsername().equals(user.getUsername()) && use.getPassword().equals(user.getPassword())){
                return true;
            }
        }

        return false;
    }



}

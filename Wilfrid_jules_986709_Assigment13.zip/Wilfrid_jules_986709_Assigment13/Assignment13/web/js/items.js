// $(function () {
//     alert("hi");
//     $("#chocoCheck").onchange=alert("changed");
//
//     $("#chocoCheck").checked(function () {
//         if($("#chocolateQuantity").val()==0){
//             $("#chocolateQuantity").value=0;
//
//         }
//
//     });
// })();

(window.onload=function () {

    document.getElementById(("chocoCheck")).onclick=function (){alert("chocobox change")};

})();
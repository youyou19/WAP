$(document).ready(function () {

//Delete AJAX

    $(".delete").click(function () {
        var id = +this.id;
        $.ajax({
            url: "/student",
            type: "get",
            data: {
                studentId: id,
                command: "DELETE"
            },
            success: function (data) {
                alert(data); // alerts the response from jsp
                location.reload();
            }
        });
    });

    //Update AJAX

    $(".update").click(function () {
        var id = +this.id;
        var inputObject = "input#"+id+".password";
        var newPassword = $(inputObject).val();
        $.ajax({
            url: "/student",
            type: "get",
            data: {
                id: id,
                password : newPassword,
                command: "UPDATE"
            },
            success: function (data) {
                alert(data); // alerts the response from jsp
                location.reload();
            }
        });
    });


});

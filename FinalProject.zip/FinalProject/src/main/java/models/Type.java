package models;

public enum Type {
    Student,Admin,Faculty,Staff
}

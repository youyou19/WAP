

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
public class HelloServlet  extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Test</title></head><body>");
        out.print("<form method='post'  action ='/helloservlet_war_exploded/support'>");
        out.print(" name <input type='text' value='' name='name'/></br></br>" );
        out.print(" Email Adress <input type='text' value='' name='email'/></br></br>");
        out.print(" Problem <input type='text' value='' name='description'/> </br></br>");
        out.print(" Problem description <div><textArea rows='5' cols='30'>   </textArea></div></br></br>");

        out.print("<input type='submit' value='Help'/>");
        out.print("</form>");
        out.print("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      PrintWriter out = response.getWriter();

        String name=request.getParameter("name");
        String email=request.getParameter("email");
        String  description=request.getParameter("description");

        out.print (" Thank you! ["+name+"] for contacting us. We should receive reply from us with in 24 hrs in your email address ["+email+"]."+
                   " Let us know in our support email ["+description+"] if you don’t receive reply within 24 hrs."+
                   "Please be sure to attach your reference [support_ticket_id] in your email."+
                   "Support_email should come from context param."+
                   " Support_ticket_id is generated automatically for every request");

    }
}
